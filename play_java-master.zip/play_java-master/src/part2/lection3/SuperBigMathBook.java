package part2.lection3;

public class SuperBigMathBook extends MathBook {

	// @Override
	void explain(String i) {
		System.out.println("explain(String)");
	}
}
