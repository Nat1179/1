package part2.lection1;

public class CastingNumbers {
	public static void main(String[] args) {
		double above = 0.7, belov = 0.4;
		float fabove = 0.7f, fbelov = 0.4f;
		System.out.println("(int)above: " + (int) above);
		System.out.println("(int)belov: " + (int) belov);
		System.out.println("(int)fabove: " + (int) fabove);
		System.out.println("(int)fbelov: " + (int) fbelov);

	}

}
