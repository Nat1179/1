package part2.lection1;

public class Casting {

	public static void main(String[] args) {
		int i = 10;
		long lng = i;
		lng = i; 

		long lng2 = 200;

		lng2 = 200;
					

		i = (int) lng2;
		// i=lng2;
	}

}
