package part2.lection1;

class Teacher {
}

public class DefaultConstructor {
	public static void main(String[] args) {
		Teacher t = new Teacher(); 
	}
}
