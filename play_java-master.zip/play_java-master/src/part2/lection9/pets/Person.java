package part2.lection9.pets;

public class Person extends Individual {
  public Person(String name) { super(name); }
} ///:~
