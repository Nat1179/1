package part2.lection7.notepad;

public class Notepad {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		NotepadFrame mainForm = new NotepadFrame();
		mainForm.setBounds(200,100,400,300);
		mainForm.setVisible(true);

	}

}
