package part2.lection2;

public class Student {
	
	Student(){
		System.out.println("Створили студента з  пакету ua.com.glybovets.lecture4");
	}
	void enrol(){
		System.out.println("Зарахувати студента");
	}
}
