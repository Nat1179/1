package part2.lection2;

//Так набагато зручніше
import part2.lection2.access.*;

public class ImportedMyClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyClass m = new MyClass();

	}

}
