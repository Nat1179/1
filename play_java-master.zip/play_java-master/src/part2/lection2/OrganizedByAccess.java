package part2.lection2;

public class OrganizedByAccess {
	
	public int i;
	public double b;
	public String s;
	
	public void pub1(){/* */}
	public void pub2(){/* */}
	public void pub3(){/* */}
	
	int k;
	
	void default1(){/* */}
	void default2(){/* */}
	void default3(){/* */}
	
	private void priv1(){/*  */}
	private void priv2(){/*  */}
	private void priv3(){/*  */}
	
	private int j;
	//..
}
