/**
 * Клас для демонстрації доступу на рівні пакетів
 */
package part2.lection2.access;

public class MyClass {
	public MyClass(){
		System.out.println("Мій клас з пакету ua.com.glybovets.lection5.access");
	}
}
