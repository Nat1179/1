/**
 * Приклад демонструє вирішення конфлікту імен в Java
 */
package part2.lection2;

import java.util.*;

public class AccessConflict {

	public static void main(String[] args) {

		//Давайте розкоментуємо наступну стрічку і подивимося на 
		//поведінку компілятора
		//Vector v = new Vector(); 

	}

}
