package part2.lection8.inner;

public class Math {
	private int i;

	Math(int i) {
		this.i = i;
	}

	public int value() {
		return i;
	}
}
