package part2.lection8.car3;

public interface Engine {

	public String getDeveloper();

	public void start();

	public void stop();
}
