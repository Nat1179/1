package part2.lection8.car3;

public interface GearBox {
	public int maxGear();

	public int gear();

	public void next();

	public void prev();
}
