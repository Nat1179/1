package part2.lection5.solution;

import part2.lection5.fail.*;

// інтерфейс клабера
public interface Clubber {

	public String знайомитись(Дівчина d);

	public String getName();

	public String rockTheClub();

}
