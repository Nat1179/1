package part2.lection5.solution;

import part2.lection5.fail.*;

// місце для клабінгу :)
public class Club {

	public static void clubbing(Clubber c, Дівчина d) {
		System.out.println(c.getName());
		System.out.println(c.знайомитись(d));
	}

}