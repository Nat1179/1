package part2.lection5.cars3;

public enum Petrol {
	P92, P95, P95_PLUS, SUPER;
}
