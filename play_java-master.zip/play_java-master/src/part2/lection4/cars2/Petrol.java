package part2.lection4.cars2;

/**
 * тип переліка
 * 
 * @author Andrii
 * 
 */
public enum Petrol {
	P92, P95, P95_PLUS, SUPER;
}
