package part2.lection4.shape;

public class Shape {
	public void draw() {
	}

	public void erase() {
	}
}
