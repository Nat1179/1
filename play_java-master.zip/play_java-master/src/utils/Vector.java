package utils;

public class Vector {

	public Vector() {
		System.out.println("MY SUPER VECTOR");
	}
}
